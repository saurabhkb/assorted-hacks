# -*- coding: utf-8 -*-
from crawler import Crawler
c = Crawler()
c.traverse('Ubuntu_(operating_system)')
#c.traverse('Information_technology_companies_of_the_United_States')
#c.traverse('Video_game_companies_of_the_United_States')
