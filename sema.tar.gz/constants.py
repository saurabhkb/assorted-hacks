#database connection params
HOST = 'localhost'
USER = 'root'
PASSWORD = 'saurabh'
DB_NAME = 'sema'
MAX_USER_ID_LEN = 50
DATA_TABLE = 'data'
USER_TABLE = 'users'

#table column names
INTEREST = 'interest'
FREQUENCY = 'frequency'
LAST_ACCESS = 'last_accessed'
TYPE = 'type'

#statuses
SUCCESS = 1
FAILURE = 0

#GET params
DELIM = ','
API_KEY = 'api_key'
USER_ID = 'user_id'
SUPPLIED = 'supplied'
SUPPLIED_ID = 0
GENERATED = 'generated'
GENERATED_ID = 1


#error messages
AUTH_FAIL = 'authentication error'
INVALID_ARG = 'invalid argument supplied'
INVALID_HTTP_VERB = 'invalid http verb used for this endpoint'
RESOURCE_NOT_FOUND = 'resource not found'

#datastore namespaces
USERS = "users"
INTERESTS = "interests"
STOPWORDS = "stopwords"
